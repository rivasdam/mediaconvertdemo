import json
import os
import boto3



def add_object(videos, filename):
    aux = filename.split('.')
    video_info = {
        'name': filename,
        'thumbnail': aux[0] + '.jpg'
    }
    videos.append(video_info)
    

def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    bucket = os.environ["BUCKET"]
    prefix = os.environ["PREFIX"]
    files = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter='/')
    
    videos = []
    
    for filename in files['Contents']:
        if not (filename['Key'] == 'input/'):
            video_file = filename['Key'].split('/')
            add_object(videos, video_file[1])
    

    return {
        'statusCode': 200,
         "headers": {
            "Access-Control-Allow-Origin": "*"
        },
        'body': json.dumps(videos)
    }
