import json
import os
import decimal
import boto3
from boto3.dynamodb.conditions import Key


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)

def split_s3_path(s3_path):
    path_parts=s3_path.replace("s3://","").split("/")
    bucket=path_parts.pop(0)
    key="/".join(path_parts)
    return bucket, key


def lambda_handler(event, context):
    
    dynamo = boto3.resource('dynamodb')
    table = dynamo.Table(os.environ["EventTable"])
    
    s3 = boto3.client('s3')
    
    jobId = event['queryStringParameters']['jobId']
    #jobId = "1608324591004-9sq2lf"
    
    query=table.query(
        IndexName='jobId-index',
        KeyConditionExpression=Key('jobId').eq(jobId)
    )
    
    response = query['Items']
    
    if (len(response) !=0):
    
        if (response[0]['detail']['status'] == "COMPLETE"):
            for video in response[0]['detail']['outputGroupDetails']:
                if(video["type"] == "FILE_GROUP"):
                    bucket_data = split_s3_path(video['outputDetails'][0]['outputFilePaths'][0])
                    #si no se usa Cloudfront adelante de S3, se genera la presigned URL temporal para descargar el archivo
                    #url = s3.generate_presigned_url(ClientMethod='get_object', Params={'Bucket': bucket_data[0],'Key': bucket_data[1]},ExpiresIn=60)
                    
                    #Si se usa Cloudfront:
                    url= os.environ['CloudfrontDistribution']+bucket_data[1]
                    status = "COMPLETE",
                    message = url
                    print(url)
                    break
                
        elif (response[0]['detail']['status'] == "ERROR"):
            status = "ERROR"
            message = response[0]['detail']['errorMessage']+" (Error code: "+str(response[0]['detail']['errorCode'])+")"
    else:
        status = "PROGRESSING"
        message = ""
    
    result = {"status": status, "message": message}
            
    resp = {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(result)
    }
    
    return resp
